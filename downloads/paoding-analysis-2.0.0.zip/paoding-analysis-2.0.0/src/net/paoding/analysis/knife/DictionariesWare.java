package net.paoding.analysis.knife;

public interface DictionariesWare {

	public void setDictionaries(Dictionaries dictionaries);

}
